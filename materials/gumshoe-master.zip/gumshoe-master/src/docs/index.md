This demo also uses [Smooth Scroll](https://github.com/cferdinandi/smooth-scroll) to animate scrolling to anchor links.

<p id="eenie">Eenie...</p>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>

<p id="meanie">Meanie...</p>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>

<p id="minnie">Minnie...</p>
.<br>
.<br>
.<br>
.<br>


<p id="moe">Moe...</p>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>
.<br>

<p><a data-scroll href="#top">Back to the top</a></p>