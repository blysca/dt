module.exports = require('./src/index').default;
